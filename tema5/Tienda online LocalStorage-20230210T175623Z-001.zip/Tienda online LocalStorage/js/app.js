// Importamos la base de datos
import {productos} from "../db/db.js";