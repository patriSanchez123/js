import {mostrarResultado} from "./ignorar.js";

/**
 * Método que crea todos los listeners necesarios para el tratamiento de errores en el formulario
 */
function crearListeners() {
    // Evento para el tratamiento de los errores al hacer "submit" en el formulario
    document.getElementById("formulario").addEventListener("submit", validarActividades, false);
}

crearListeners();

function validarActividades(e) {
    e.preventDefault();
    const texto = document.getElementById("prueba").value;
    let cumpleExprReg = false;

    // Actividad 1: considera este código como un ejemplo
    const expr1 = /cosas/;
    cumpleExprReg = expr1.test(texto);
    ///////////////////////////////// AQUÍ EL RESTO DE ACTIVIDADES: \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    /* Aquí el código de todas las actividades. Hay que usar las variables: 
        - "texto": que contiene el texto del campo
        - "cumpleExprReg": que contendrá un booleano que indica si se cumple o no la expresión regular
        Nota: tomar como ejemplo la actividad 1
    */
    // Actividad 2:

    // Actividad 3:

    // Actividad 4:

    // Actividad 5:

    // Actividad 6:

    // Actividad 7:

    // Actividad 8:

    // Actividad 9:

    // Actividad 10:

    // Actividad 11:

    // Actividad 12:

    // Actividad 13:

    // Actividad 14:

    
    ///////////////////////////////// FIN ACTIVIDADES \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    // Mostramos el resultado de la expresión regular
    mostrarResultado(texto, cumpleExprReg);
}