document.getElementById("enviar").addEventListener("click", cambiarContenidoConTexto, false);

function cambiarContenidoConTexto(e) {
    e.preventDefault();
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if(this.readyState === 4 /*XMLHTTPRequest.DONE*/ && this.status === 200) {
            document.getElementById("contenedorMensaje").innerHTML = this.responseText;
        }
    };

    /* Con "open" se especifica la solicitud que se va a hacer. Sus atributos son:
        - Método: GET/POST
        - URL: puede señalar directamente a un archivo txt, xml, json, página php, etc
        - Asíncrono: true/false -> si true, petición se hace de forma asíncrona. En caso de que sea false
                       el método "send" bloqueará la aplicación hasta que reciba la respuesta
                       (no se hará de forma asíncrona, quedando la interfaz bloqueada)
    */
   xhr.open("GET", "http://127.0.0.1:5501/AJAX_texto/res/pruebaAjax.txt", true);
   /* El método "send" envía la petición al servidor. Sus atributos son:
        - cuerpo: si el método es POST, se usa para pasar el cuerpo de la petición.
                        En caso de petición GET (como en esta ocación) no se especifica
                        este parámetro o se pone a "null"
    */
   xhr.send();
}