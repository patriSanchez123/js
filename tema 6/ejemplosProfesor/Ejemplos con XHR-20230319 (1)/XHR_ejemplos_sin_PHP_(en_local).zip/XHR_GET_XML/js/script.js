document.getElementById("enviar").addEventListener("click", cargarPeliculas, false);

function cargarPeliculas(e) {
    e.preventDefault();
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if(this.readyState === 4 /*XMLHTTPRequest.DONE*/ && this.status === 200) {
            parseaXML(this.responseXML);
        }
    };

   xhr.open("GET", "http://127.0.0.1:5501/AJAX_XML/res/pruebaAjax.xml", true);
   /* El método "send" envía la petición al servidor. Sus atributos son:
        - cuerpo: si el método es POST, se usa para pasar el cuerpo de la petición.
                        En caso de petición GET (como en esta ocación) no se especifica
                        este parámetro o se pone a "null"
    */
   xhr.send();
}

function parseaXML(xml) {
    const encabezado = "<thead><tr><th>Título</th><th>Género</th><td>Director/a</th><th>Fecha</th></tr></thead>";
    let cuerpo = "<tbody>";
    const peliculasXML = xml.getElementsByTagName("Pelicula");
    for(let peliculaXML of peliculasXML) {
        const titulo = peliculaXML.getElementsByTagName("Titulo")[0].textContent;
        const genero = peliculaXML.getElementsByTagName("Genero")[0].textContent;
        const director = peliculaXML.getElementsByTagName("Director")[0].textContent;
        const fecha = peliculaXML.getElementsByTagName("Fecha")[0].textContent;
        cuerpo += `<tr>
                        <td>${titulo}</td>
                        <td>${genero}</td>
                        <td>${director}</td>
                        <td>${fecha}</td>
                    </tr>
                  `;
    }
    cuerpo += "<tbody>";
    document.getElementById("peliculas").innerHTML = encabezado + cuerpo;
}