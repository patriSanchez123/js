<?php
// Array que se va a usar para sugerir nombres (esto debería de venir de BBDD)
$arrayNombres = array("Antonio", "Maria", "Jose Maria", "Daniel", "Marcos", "Laura", "Miguel",
"Amancio", "Arturo", "Debla", "Amparo", "Ivan", "Alicia", "Ana Maria", "Susana", "Patricia",
"Alvaro", "Alberto", "Ana", "Alejandro", "Justiniano");

$nombre = $_REQUEST["nombre"];
$sugerenciaNombres = "";

if($nombre !== "") {
    // Nombre a minúsculas
    $nombre = strtolower($nombre);
    // Longitud del nombre
    $longitud = strlen($nombre);

    foreach($arrayNombres as $nombreArray) {
        $subcadena = substr($nombreArray, 0, $longitud);
        // Coincide el nombre pasado con una porción igual de cada nombre del arrayde sugerencias
        if(stristr($nombre, $subcadena)) {
            if ($sugerenciaNombres === "") {
                $sugerenciaNombres = $nombreArray;
            }else {
                $sugerenciaNombres = "$sugerenciaNombres, $nombreArray";
            }
        }
    }
}

echo ($sugerenciaNombres === "") ? "Sin sugerencias" : $sugerenciaNombres;
?>