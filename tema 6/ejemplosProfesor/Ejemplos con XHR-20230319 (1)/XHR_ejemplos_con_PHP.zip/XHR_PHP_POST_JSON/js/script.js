document.getElementById("idProducto").addEventListener("input", obtenerProducto, false);

function obtenerProducto(e) {
    const idProducto = e.target.value;

    if(idProducto === "000") {
        document.getElementById("contenedorProducto").innerHTML = "";  
    }else {
        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if(this.readyState === 4 /*XMLHTTPRequest.DONE*/ && this.status === 200) {
                muestraProductoHTML(JSON.parse(this.responseText));
            }
        };
        xhr.open("POST", "tienda.php", true);
        // Tiene que ser llamado después del "open" y antes que el "send"
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(`idProducto=${idProducto}`);
    }
}

function muestraProductoHTML(producto) {
    const contenedor = document.getElementById("contenedorProducto");
    
    const {id, nombre, categoria, imagen, precio, vendedor, stock} = producto;

    contenedor.innerHTML = `
    <article id="${id}" class="location-listing" data-categoria="${categoria}">
        <div class="location-image">
            <a href="#">
                <img src="${imagen}" alt="${nombre}">
            </a>
        </div>
        <div class="data">
            <h4>${nombre}</h4>
            <p class="price">${precio}€</p>
            <p>Vendido por <strong>${vendedor}</strong></p>
            <p>Quedan ${stock} unidades</p>
            <div class="button-container">
                <a class="button add" href="#" target="_blank">Añadir al carrito</a>
            </div>
        </div>
    </article>
    `;

}