document.getElementById("nombre").addEventListener("input", obtenerSugerencias, false);

function obtenerSugerencias(e) {
    const contenidoNombre = e.target.value;

    if(contenidoNombre === "") {
        document.getElementById("contenedorSugerencias").textContent = "";  
    }else {
        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if(this.readyState === 4 /*XMLHTTPRequest.DONE*/ && this.status === 200) {
                document.getElementById("contenedorSugerencias").textContent = this.responseText;
            }
        };
        xhr.open("GET", `sugerencias.php?nombre=${contenidoNombre}`, true);
        xhr.send();
    }
}